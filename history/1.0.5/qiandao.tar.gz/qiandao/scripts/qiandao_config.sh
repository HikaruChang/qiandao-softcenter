#!/bin/sh

export KSROOT=/koolshare
source $KSROOT/scripts/base.sh
eval `dbus export qiandao_`
logfile="/tmp/upload/qiandao_log.txt"

start_qiandao(){
	[ -n "$qiandao_tieba" ] && tieba="\"tieba\"=$(echo $qiandao_tieba | base64_decode)" || tieba=""
	[ -n "$qiandao_bilibili" ] && bilibili="\"bilibili\"=$(echo $qiandao_bilibili | base64_decode)" || bilibili=""
	[ -n "$qiandao_smzdm" ] && smzdm="\"smzdm\"=$(echo $qiandao_smzdm | base64_decode)" || smzdm=""
	[ -n "$qiandao_v2ex" ] && v2ex="\"v2ex\"=$(echo $qiandao_v2ex | base64_decode)" || v2ex=""
	[ -n "$qiandao_hostloc" ] && hostloc="\"hostloc\"=$(echo $qiandao_hostloc | base64_decode)" || hostloc=""
	echo -e "$tieba\n$bilibili\n$smzdm\n$v2ex\n$hostloc\n########################END################" > $KSROOT/qiandao/cookie.conf
	sed -i '/qiandao/d' /etc/crontabs/root
	echo "0 $qiandao_time * * * $KSROOT/scripts/qiandao_config.sh" >> /etc/crontabs/root
	cd /koolshare/qiandao && ./qiandao > $logfile 2>&1 &
}

stop_qiandao(){
	sed -i '/qiandao/d' /etc/crontabs/root
}

# used by httpdb
if [ "$qiandao_enable" == "1" ];then
	start_qiandao
	http_response '设置已保存！切勿重复提交！页面将在1秒后刷新'
else
	stop_qiandao
	http_response '设置已保存！切勿重复提交！页面将在1秒后刷新'
fi
